table! {
    users (id) {
        id -> Int4,
        login -> Text,
    }
}
