DROP TABLE users;
